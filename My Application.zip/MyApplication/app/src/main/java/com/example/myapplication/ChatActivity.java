package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ChatActivity extends AppCompatActivity {

    public User u = new User();
    EditText message, to;
    Button send;
    DBHelper mdb;
    SQLiteDatabase db;
    MessageActivity mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        Intent i = getIntent();
        u.phone = i.getStringExtra("FROM");

        to = findViewById(R.id.editTextPhone2);
        message = findViewById(R.id.textView5);

        mdb = new DBHelper(this);
        db = mdb.getWritableDatabase();
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        mAdapter = new MessageActivity(this, getAllItems());
        recyclerView.setAdapter(mAdapter);

        send = findViewById(R.id.button5);

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addMessages();
            }
        });
    }

    private void addMessages() {
        if (message.getText().toString().trim().length() == 0) {
            return;
        }
        u.message = message.getText().toString();
        u.to_phone = to.getText().toString();
        Boolean checkinsertmessage = mdb.sentusermessage(u.phone,u.to_phone,u.message);
        if (checkinsertmessage == true)
            Toast.makeText(ChatActivity.this, "Message Sent", Toast.LENGTH_LONG).show();
        else
            Toast.makeText(ChatActivity.this, "Retry Again", Toast.LENGTH_LONG).show();

        mAdapter.swapCursor(getAllItems());
        message.getText().clear();
    }

    private Cursor getAllItems() {
        return db.query(
                "Messagelogs",
                null,
                null,
                null,
                null,
                null,
                "ASC"
        );
    }


}