package com.example.myapplication;

public class User {
    public String name;
    public String phone;
    public String to_phone;
    public String message;
}
